package com.example.sklep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SklepApplicationTests {

	@Test
	void contextLoads() {
	}

}
