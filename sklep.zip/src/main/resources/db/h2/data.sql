INSERT INTO Product VALUES (1, 'pierwszy produkt');
INSERT INTO Product VALUES (2, 'drugi produkt');
INSERT INTO Product VALUES (3, 'trzeci produkt');